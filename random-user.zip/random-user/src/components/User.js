import React, { useEffect, useState } from 'react';

const User = () => {
    const [data, setData] = useState(null);

    useEffect(() => {
      fetch('https://randomuser.me/api/?page=1&results=1&seed=abc')
        .then((response) => response.json())
        .then((data) => setData(data.results[0]))
        .catch((error) => console.error('Error fetching user data:', error));
    }, []);
  
    if (!data) {
      return <div className="flex justify-center items-center h-screen">Loading...</div>;
    }
    
    return (
        <div className="App w-full h-screen flex flex-wrap justify-center items-center bg-cover bg-no-repeat" style={{
            backgroundImage: `url('https://png.pngtree.com/thumb_back/fh260/back_our/20190619/ourmid/pngtree-company-profile-corporate-culture-exhibition-board-display-poster-material-image_131622.jpg')`,
        }}>
          {data && (
            <div className="min-h-screen dark:bg-slate-800 gap-8 flex items-center justify-center">
              <div className="bg-gradient-to-r from-cyan-500 to-blue-500 relative shadow-xl overflow-hidden  p-12 ">
                <div className="flex items-center gap-12">  
                  <img src={data.picture.large} className="w-56 h-76 object-center object-cover "/>
                  <div className="w-fit ">
                    <h1 className="text-gray-600 dark:text-gray-200 font-bold text-4xl">{data.name.first} {data.name.last}</h1>
                    <p className="text-gray-600 text-2xl">{data.gender}</p>
                    <p className="text-gray-600 text-xl">{data.phone}</p>
                  </div>
                </div>
              </div>
            </div>
        )}
        </div>
    );
}

export default User;
