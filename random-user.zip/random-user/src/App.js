import React from 'react';
import User from './components/User';

function App() {
  return (
    <div>
      <User />
    </div>
  );
}

export default App;


